#!/bin/sh

chmod a+rx /usr/bin/hostapd
chmod a+rx /usr/bin/miniupnpd
chmod a+rx /usr/sbin/udhcpd